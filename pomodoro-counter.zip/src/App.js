import "./styles.css";
import React, { useState, useEffect } from "react";

export default function App() {
  const [second, setseconds] = useState(0);
  const [minute, setminute] = useState(25);
  let [timer, settimer] = useState(true);

  setTimeout(() => {
    if (timer === false) {
      if (second > 0) {
        if (minute >= 0) {
          setseconds(second - 1);
        }
      } else if (second === 0) {
        if (minute > 0) {
          setminute(minute - 1);
          setseconds(59);
        }
      }
    }
  }, 1000);
  console.log(second);
  return (
    <div className="App">
      <div className="sidebar">
        <div className="sidebar-block" style={{ marginTop: "25vh" }}>
          <botton>
            <i class="fa-solid fa-clock"></i>Timer
          </botton>
        </div>
        <div className="sidebar-block">
          <botton>
            <i class="fa-solid fa-signal"></i>Stats
          </botton>
        </div>
        <div className="sidebar-block">
          <botton>
            <i class="fa-solid fa-gear"></i>Settings
          </botton>
        </div>
        <div className="sidebar-block">
          <botton>
            <i class="fa-solid fa-circle-half-stroke"></i>Dark mode
          </botton>
        </div>
      </div>
      <div className="main">
        <div style={{ marginTop: "8vh", marginLeft: "70vw" }}>
          <button
            style={{
              height: "4vh",
              backgroundColor: "rgb(17,17,17)",
              color: "rgb(156,156,156)",
              border: "1px solid rgb(156,156,156)",
              paddingTop: "1vh",
              paddingBottom: "1vh",
              fontSize: "1.5vh",
              paddingLeft: "1vw",
              paddingRight: "1vw",
              borderRadius: "3px"
            }}
          >
            <i
              class="fa-solid fa-hat-cowboy"
              style={{ paddingRight: "4px" }}
            ></i>
            SIGN IN
          </button>
        </div>
        <div
          style={{
            marginTop: "5vh"
          }}
        >
          <button
            style={{
              height: "4vh",
              backgroundColor: "rgb(17,17,17)",
              border: "1px solid rgb(156,156,156)",
              borderRadius: "3px",
              fontSize: "11px",
              color: "rgb(84, 62, 246)"
            }}
          >
            <i
              class="fa-regular fa-circle-right"
              style={{ paddingRight: "5px" }}
            ></i>
            ADD LABEL
          </button>
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "center"
          }}
        >
          <div class="circular">
            <div class="inner"></div>
            <div class="number">
              <div style={{ marginTop: "o.8vh" }}>
                {minute > 9 ? minute : "0" + minute}:
                {second > 9 ? second : "0" + second}
              </div>
              <div style={{ fontSize: "7px", marginTop: "0.5vh" }}>FOCUS</div>
            </div>
            <div class="circle">
              <div class="bar left">
                <div class="progress"></div>
              </div>
              <div class="bar right">
                <div class="progress"></div>
              </div>
            </div>
          </div>
        </div>
        <div className="audioplayer">
          <span style={{ marginTop: "1.5vh" }}>
            <i
              style={{ fontSize: "4vh", color: "#C1C1C1" }}
              class="fa-solid fa-arrow-rotate-right"
            ></i>
          </span>
          <span>
            <a
              onClick={() => {
                timer === true ? settimer(false) : settimer(true);
              }}
            >
              <i
                style={{
                  fontSize: "7vh",
                  color: "#4158D0",
                  marginRight: "1.5vw",
                  marginLeft: "1.5vw"
                }}
                class="fa-regular fa-circle-play"
              ></i>
            </a>
          </span>
          <span style={{ marginTop: "1.5vh" }}>
            <i
              style={{ fontSize: "4vh", color: "#C1C1C1" }}
              class="fa-solid fa-forward-step"
            ></i>
          </span>
        </div>
        <div
          style={{
            marginTop: "2vh",
            textSizeAdjust: "3rem",
            color: "rgb(153,153,153)",
            fontSize: "0.95rem",
            fontWeight: "800"
          }}
        >
          <p>
            4 of 4<br></br>sessions
          </p>
        </div>
        <div
          style={{
            marginTop: "5vh",
            textSizeAdjust: "3rem",
            color: "rgb(153,153,153)",
            fontSize: "0.956rem",
            fontWeight: "800"
          }}
        >
          Made with love by Huraira Shahid
        </div>
        <div className="social">
          <span style={{ marginRight: "5px" }}>
            <i class="fa-brands fa-twitter"></i>
          </span>
          <span>
            <i class="fa-brands fa-github"></i>
          </span>
        </div>
      </div>
    </div>
  );
}
